package com.aei;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AeiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AeiApplication.class, args);
	}
}
