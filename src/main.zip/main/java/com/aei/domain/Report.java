package com.aei.domain;

public class Report {
	
	private String name;

}
