package com.aei.service;

public interface UserDetailsService {

}
